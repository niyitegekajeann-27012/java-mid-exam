/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.*;
public class Barber {
    private int barberId;
    private String name;
    private String specialty;
    private String phone;
    private String availabilityStatus;
    
    public Barber(){
        
    }

    public Barber(int barberId, String name, String specialty, String phone, String availabilityStatus) {
        this.barberId = barberId;
        this.name = name;
        this.specialty = specialty;
        this.phone = phone;
        this.availabilityStatus = availabilityStatus;
    }

    public int getBarberId() {
        return barberId;
    }

    public void setBarberId(int barberId) {
        this.barberId = barberId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSpecialty() {
        return specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAvailabilityStatus() {
        return availabilityStatus;
    }

    public void setAvailabilityStatus(String availabilityStatus) {
        this.availabilityStatus = availabilityStatus;
    }   
    
}

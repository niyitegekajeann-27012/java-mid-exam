import javax.swing.SwingUtilities;
import view.WelcomeView;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new WelcomeView().setVisible(true));
    }
}
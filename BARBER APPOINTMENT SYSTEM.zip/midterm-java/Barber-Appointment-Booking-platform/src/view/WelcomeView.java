package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class WelcomeView extends JFrame {
    public WelcomeView() {
        initializeUI();
    }

    private void initializeUI() {
        // Set frame properties
        setTitle("BarberBook - Welcome");
        setSize(700, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Set a light background color for the entire frame
        getContentPane().setBackground(new Color(240, 248, 255)); // Alice Blue

        // Header with branding
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(70, 130, 180)); // Steel Blue
        headerPanel.setBorder(new EmptyBorder(20, 0, 20, 0)); // Padding
        headerPanel.setLayout(new BorderLayout());

        JLabel appName = new JLabel("BarberBook", SwingConstants.CENTER);
        appName.setFont(new Font("Arial", Font.BOLD, 36));
        appName.setForeground(Color.WHITE);

        JLabel tagline = new JLabel("Your Ultimate Appointment Solution", SwingConstants.CENTER);
        tagline.setFont(new Font("Arial", Font.ITALIC, 16));
        tagline.setForeground(Color.WHITE);

        headerPanel.add(appName, BorderLayout.NORTH);
        headerPanel.add(tagline, BorderLayout.SOUTH);
        add(headerPanel, BorderLayout.NORTH);

        // Center panel with a welcome message and optional image
        JPanel centerPanel = new JPanel();
        centerPanel.setBackground(new Color(240, 248, 255)); // Same as frame background
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBorder(new EmptyBorder(20, 20, 20, 20)); // Padding

        JLabel welcomeMessage = new JLabel("Welcome to BarberBook!", SwingConstants.CENTER);
        welcomeMessage.setFont(new Font("Arial", Font.BOLD, 24));
        welcomeMessage.setForeground(new Color(60, 60, 60)); // Dark gray
        welcomeMessage.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subMessage = new JLabel("Book and manage your barber appointments with ease.", SwingConstants.CENTER);
        subMessage.setFont(new Font("Arial", Font.PLAIN, 16));
        subMessage.setForeground(new Color(80, 80, 80));
        subMessage.setAlignmentX(Component.CENTER_ALIGNMENT);

        
        JLabel imageLabel = new JLabel(new ImageIcon("E:/Java Projects/Smart_Banking_System/BarberBook/resources/barberlogo.jpg"));
        imageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        centerPanel.add(imageLabel);
        centerPanel.add(Box.createVerticalStrut(20)); // Spacing
 

        centerPanel.add(Box.createVerticalStrut(20)); // Spacing
        centerPanel.add(welcomeMessage);
        centerPanel.add(Box.createVerticalStrut(30)); // Spacing
        centerPanel.add(subMessage);
        add(centerPanel, BorderLayout.CENTER);

        // Navigation buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        buttonPanel.setBackground(new Color(245, 245, 220)); // Beige background
        buttonPanel.setBorder(new EmptyBorder(10, 0, 10, 0)); // Padding

        // Style the buttons
        JButton bookButton = new JButton("Book Appointment");
        JButton manageAppointmentsButton = new JButton("Manage Appointments");
        JButton manageBarbersButton = new JButton("Manage Barbers");
        JButton addCustomerButton = new JButton("Add Customer");
        JButton dashboardButton = new JButton("View Dashboard");

        // Common button styling
        JButton[] buttons = {bookButton, manageAppointmentsButton, manageBarbersButton, addCustomerButton, dashboardButton};
        for (JButton button : buttons) {
            button.setFont(new Font("Arial", Font.BOLD, 14));
            button.setForeground(Color.WHITE);
            button.setFocusPainted(false); // Remove focus border
            button.setBorder(new EmptyBorder(8, 15, 8, 15)); // Add padding inside buttons
        }

        // Individual button colors
        bookButton.setBackground(new Color(60, 179, 113)); // Medium Sea Green
        manageAppointmentsButton.setBackground(new Color(255, 165, 0)); // Orange
        manageBarbersButton.setBackground(new Color(106, 90, 205)); // Slate Blue
        addCustomerButton.setBackground(new Color(30, 144, 255)); // Dodger Blue
        dashboardButton.setBackground(new Color(147, 112, 219)); // Medium Purple

        // Add action listeners
        bookButton.addActionListener(e -> new BookAppointmentView().setVisible(true));
        manageAppointmentsButton.addActionListener(e -> new ManageAppointmentsView().setVisible(true));
        manageBarbersButton.addActionListener(e -> new BarberManagementView().setVisible(true));
        addCustomerButton.addActionListener(e -> new AddCustomerView().setVisible(true));
        dashboardButton.addActionListener(e -> new DashboardView().setVisible(true));

        // Add buttons to panel
        buttonPanel.add(bookButton);
        buttonPanel.add(manageAppointmentsButton);
        buttonPanel.add(manageBarbersButton);
        buttonPanel.add(addCustomerButton);
        buttonPanel.add(dashboardButton);
        add(buttonPanel, BorderLayout.SOUTH);

        setLocationRelativeTo(null);
    }
}
package view;

import dao.AppointmentDAO;
import dao.BarberDAO;
import dao.CustomerDAO;
import model.Appointment;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.Timestamp;

public class BookAppointmentView extends JFrame {
    private JTextField customerIdField, barberIdField, dateField;
    
    private AppointmentDAO appointmentDAO;
    private CustomerDAO customerDAO;
    private BarberDAO barberDAO;

    public BookAppointmentView() {
        this.appointmentDAO = new AppointmentDAO();
        this.customerDAO = new CustomerDAO();
        this.barberDAO = new BarberDAO();
        initializeUI();
    }
    private void initializeUI() {
        setTitle("BarberBook - Book Appointment");
        setSize(400, 350); 
        setLayout(new BorderLayout());
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        getContentPane().setBackground(new Color(240, 248, 255)); 

        JLabel header = new JLabel("Book Appointment", SwingConstants.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 24));
        header.setForeground(Color.WHITE); 
        header.setBackground(new Color(70, 130, 180)); 
        header.setOpaque(true); 
        header.setBorder(new EmptyBorder(10, 0, 10, 0)); 
        add(header, BorderLayout.NORTH);

        // Form panel for inputs
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(4, 2, 10, 10)); // 4 rows for the fields
        formPanel.setBackground(new Color(240, 248, 255)); // Alice Blue
        formPanel.setBorder(new EmptyBorder(20, 20, 20, 20)); // Add padding around the form

        // Labels and text fields
        JLabel customerIdLabel = new JLabel("Customer ID:");
        customerIdLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        customerIdLabel.setForeground(new Color(60, 60, 60)); // Dark gray
        formPanel.add(customerIdLabel);
        customerIdField = new JTextField();
        customerIdField.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(customerIdField);

        JLabel barberIdLabel = new JLabel("Barber ID:");
        barberIdLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        barberIdLabel.setForeground(new Color(60, 60, 60)); // Dark gray
        formPanel.add(barberIdLabel);
        barberIdField = new JTextField();
        barberIdField.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(barberIdField);

        JLabel dateLabel = new JLabel("Date (YYYY-MM-DD HH:MM):");
        dateLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        dateLabel.setForeground(new Color(60, 60, 60)); // Dark gray
        formPanel.add(dateLabel);
        dateField = new JTextField();
        dateField.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(dateField);

        JLabel statusLabel = new JLabel("Status (Pending/Confirmed):");
        statusLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        statusLabel.setForeground(new Color(60, 60, 60)); // Dark gray
        formPanel.add(statusLabel);
        String[] statuses = {"Pending", "Confirmed"};
        JComboBox<String> statusCombo = new JComboBox<>(statuses);
        statusCombo.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(statusCombo);

        add(formPanel, BorderLayout.CENTER);

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        buttonPanel.setBackground(new Color(245, 245, 220)); // Beige background
        buttonPanel.setBorder(new EmptyBorder(10, 0, 10, 0)); // Add padding

        JButton bookButton = new JButton("Book");
        bookButton.setFont(new Font("Arial", Font.BOLD, 14));
        bookButton.setForeground(Color.WHITE);
        bookButton.setBackground(new Color(60, 179, 113)); // Medium Sea Green (same as "Book Appointment" button)
        bookButton.setFocusPainted(false); // Remove focus border
        bookButton.setBorder(new EmptyBorder(8, 15, 8, 15)); // Add padding inside button
        bookButton.addActionListener(e -> bookAppointment(statusCombo.getSelectedItem().toString()));
        buttonPanel.add(bookButton);
        add(buttonPanel, BorderLayout.SOUTH);
        setLocationRelativeTo(null);
    }
    private void bookAppointment(String status) {
        try {
            // Validate CustomerId Required
            int customerId;
            try {
                customerId = Integer.parseInt(customerIdField.getText());
            } catch (NumberFormatException e) {
                throw new Exception("Customer ID must be a number");
            }
            if (customerDAO.getCustomerById(customerId) == null) {
                throw new Exception("Customer ID does not exist");
            }

            // Validate BarberId Required
            int barberId;
            try {
                barberId = Integer.parseInt(barberIdField.getText());
            } catch (NumberFormatException e) {
                throw new Exception("Barber ID must be a number");
            }
            if (barberDAO.getBarberById(barberId) == null) {
                throw new Exception("Barber ID does not exist");
            }

            // Validate Appointment Date Regex and Min
            String dateStr = dateField.getText();
            if (!dateStr.matches("^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}$")) {
                throw new Exception("Date must be in YYYY-MM-DD HH:MM format");
            }
            
            String dateStrWithSeconds = dateStr + ":00";
            Timestamp date = Timestamp.valueOf(dateStrWithSeconds);
            if (date.before(new Timestamp(System.currentTimeMillis()))) {
                throw new Exception("Date must be in the future");
            }

            // Validate Status Char Range
            if (status.length() < 7 || status.length() > 20) {
                throw new Exception("Status must be 7-20 characters");
            }

            Appointment appointment = new Appointment(0, customerId, barberId, date, status);
            appointmentDAO.addAppointment(appointment);
            JOptionPane.showMessageDialog(this, "Appointment booked successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            dispose();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    
}
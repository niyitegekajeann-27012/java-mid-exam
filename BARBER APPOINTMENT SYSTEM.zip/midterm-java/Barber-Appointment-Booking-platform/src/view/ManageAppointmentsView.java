package view;

import dao.AppointmentDAO;
import model.Appointment;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.util.List;

public class ManageAppointmentsView extends JFrame {
    private JTable appointmentTable;
    private AppointmentDAO appointmentDAO;

    public ManageAppointmentsView() {
        this.appointmentDAO = new AppointmentDAO();
        initializeUI();
    }

    private void initializeUI() {
        // Set frame properties
        setTitle("BarberBook - Manage Appointments");
        setSize(700, 500);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Set a light background color for the entire frame
        getContentPane().setBackground(new Color(240, 248, 255)); // Alice Blue

        // Header
        JLabel header = new JLabel("Manage Appointments", SwingConstants.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 24));
        header.setForeground(Color.WHITE); // White text
        header.setBackground(new Color(70, 130, 180)); // Steel Blue
        header.setOpaque(true); // Make background color visible
        header.setBorder(new EmptyBorder(10, 0, 10, 0)); // Add padding
        add(header, BorderLayout.NORTH);

        // Table for appointments
        String[] columns = {"ID", "Customer ID", "Barber ID", "Date", "Status"};
        List<Appointment> appointments;
        try {
            appointments = appointmentDAO.getAllAppointments();
            if (appointments == null) {
                appointments = new java.util.ArrayList<>(); // Handle null return
            }
        } catch (Exception e) {
            appointments = new java.util.ArrayList<>();
            JOptionPane.showMessageDialog(this, "Error loading appointments: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        Object[][] data = new Object[appointments.size()][5];
        for (int i = 0; i < appointments.size(); i++) {
            Appointment a = appointments.get(i);
            data[i][0] = a.getAppointmentId();
            data[i][1] = a.getCustomerId();
            data[i][2] = a.getBarberId();
            data[i][3] = a.getAppointmentDate();
            data[i][4] = a.getStatus();
        }

        // Create and style the JTable
        appointmentTable = new JTable(data, columns);
        appointmentTable.setRowHeight(25); // Increase row height for better readability
        appointmentTable.setFont(new Font("Arial", Font.PLAIN, 14));
        appointmentTable.setBackground(Color.WHITE); // White background for table
        appointmentTable.setForeground(Color.BLACK); // Black text
        appointmentTable.setGridColor(new Color(200, 200, 200)); // Light gray grid lines
        appointmentTable.setSelectionBackground(new Color(173, 216, 230)); // Light Blue selection
        appointmentTable.setSelectionForeground(Color.BLACK);

        // Style the table header
        JTableHeader tableHeader = appointmentTable.getTableHeader();
        tableHeader.setBackground(new Color(100, 149, 237)); // Cornflower Blue
        tableHeader.setForeground(Color.WHITE); // White text
        tableHeader.setFont(new Font("Arial", Font.BOLD, 14));

        JScrollPane scrollPane = new JScrollPane(appointmentTable);
        scrollPane.setBorder(new EmptyBorder(10, 10, 10, 10)); // Add padding around the table
        add(scrollPane, BorderLayout.CENTER);

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        buttonPanel.setBackground(new Color(245, 245, 220)); // Beige background
        buttonPanel.setBorder(new EmptyBorder(10, 0, 10, 0)); // Add padding

        JButton deleteButton = new JButton("Delete Appointment");
        deleteButton.setFont(new Font("Arial", Font.BOLD, 14));
        deleteButton.setForeground(Color.WHITE);
        deleteButton.setBackground(new Color(255, 69, 0)); // OrangeRed for delete action
        deleteButton.setFocusPainted(false); // Remove focus border
        deleteButton.setBorder(new EmptyBorder(8, 15, 8, 15)); // Add padding inside button
        deleteButton.addActionListener(e -> deleteAppointment());

        

        buttonPanel.add(deleteButton);
        add(buttonPanel, BorderLayout.SOUTH);

        setLocationRelativeTo(null);
    }

    private void deleteAppointment() {
        int selectedRow = appointmentTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an appointment to delete.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int appointmentId = (int) appointmentTable.getValueAt(selectedRow, 0); // Get appointmentId from the selected row
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this appointment?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                appointmentDAO.deleteAppointment(appointmentId);
                JOptionPane.showMessageDialog(this, "Appointment deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                refreshTable();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error deleting appointment: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void refreshTable() {
        List<Appointment> appointments;
        try {
            appointments = appointmentDAO.getAllAppointments();
            if (appointments == null) {
                appointments = new java.util.ArrayList<>();
            }
        } catch (Exception e) {
            appointments = new java.util.ArrayList<>();
            JOptionPane.showMessageDialog(this, "Error loading appointments: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        Object[][] data = new Object[appointments.size()][5];
        for (int i = 0; i < appointments.size(); i++) {
            Appointment a = appointments.get(i);
            data[i][0] = a.getAppointmentId();
            data[i][1] = a.getCustomerId();
            data[i][2] = a.getBarberId();
            data[i][3] = a.getAppointmentDate();
            data[i][4] = a.getStatus();
        }
        appointmentTable.setModel(new javax.swing.table.DefaultTableModel(data, new String[]{"ID", "Customer ID", "Barber ID", "Date", "Status"}));
    }
}
package view;

import dao.CustomerDAO;
import model.Customer;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.Date;

public class AddCustomerView extends JFrame {
    private JTextField nameField, phoneField, emailField, regDateField;
    private CustomerDAO customerDAO;

    public AddCustomerView() {
        this.customerDAO = new CustomerDAO();
        initializeUI();
    }

    private void initializeUI() {
        // Set frame properties
        setTitle("BarberBook - Add Customer");
        setSize(400, 350); // Slightly increased height to accommodate header
        setLayout(new BorderLayout()); // Changed to BorderLayout for header and form
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        // Set a light background color for the entire frame
        getContentPane().setBackground(new Color(240, 248, 255)); // Alice Blue

        // Header
        JLabel header = new JLabel("Add New Customer", SwingConstants.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 24));
        header.setForeground(Color.WHITE); // White text
        header.setBackground(new Color(70, 130, 180)); // Steel Blue
        header.setOpaque(true); // Make background color visible
        header.setBorder(new EmptyBorder(10, 0, 10, 0)); // Add padding
        add(header, BorderLayout.NORTH);

        // Form panel for inputs
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(4, 2, 10, 10)); // 4 rows for the fields
        formPanel.setBackground(new Color(240, 248, 255)); // Alice Blue
        formPanel.setBorder(new EmptyBorder(20, 20, 20, 20)); // Add padding around the form

        // Labels and text fields
        JLabel nameLabel = new JLabel("Customer Name:");
        nameLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        nameLabel.setForeground(new Color(60, 60, 60)); // Dark gray
        formPanel.add(nameLabel);
        nameField = new JTextField();
        nameField.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(nameField);

        JLabel phoneLabel = new JLabel("Phone:");
        phoneLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        phoneLabel.setForeground(new Color(60, 60, 60)); // Dark gray
        formPanel.add(phoneLabel);
        phoneField = new JTextField();
        phoneField.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(phoneField);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        emailLabel.setForeground(new Color(60, 60, 60)); // Dark gray
        formPanel.add(emailLabel);
        emailField = new JTextField();
        emailField.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(emailField);

        JLabel regDateLabel = new JLabel("Registration Date (YYYY-MM-DD):");
        regDateLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        regDateLabel.setForeground(new Color(60, 60, 60)); // Dark gray
        formPanel.add(regDateLabel);
        regDateField = new JTextField();
        regDateField.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(regDateField);

        add(formPanel, BorderLayout.CENTER);

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        buttonPanel.setBackground(new Color(245, 245, 220)); // Beige background
        buttonPanel.setBorder(new EmptyBorder(10, 0, 10, 0)); // Add padding

        JButton addButton = new JButton("Add Customer");
        addButton.setFont(new Font("Arial", Font.BOLD, 14));
        addButton.setForeground(Color.WHITE);
        addButton.setBackground(new Color(60, 179, 113)); // Medium Sea Green (same as "Book Appointment" button)
        addButton.setFocusPainted(false); // Remove focus border
        addButton.setBorder(new EmptyBorder(8, 15, 8, 15)); // Add padding inside button
        addButton.addActionListener(e -> addCustomer());

        buttonPanel.add(addButton);
        add(buttonPanel, BorderLayout.SOUTH);

        setLocationRelativeTo(null);
    }

    private void addCustomer() {
        try {
            String name = nameField.getText();
            String phone = phoneField.getText();
            String email = emailField.getText();
            String regDateStr = regDateField.getText();

            // Validate Name Required and Char Range
            if (name == null || name.trim().isEmpty()) {
                throw new Exception("Name is required");
            }
            if (name.length() < 2 || name.length() > 100) {
                throw new Exception("Name must be 2-100 characters");
            }

            if (phone == null || phone.trim().isEmpty()) {
                 throw new Exception("Phone is required");
            }

            // Validate Email Regex
            if (!email.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$")) {
                throw new Exception("Invalid email format");
            }

            // Validate Registration Date Max
            Date regDate = Date.valueOf(regDateStr);
            if (regDate.after(new Date(System.currentTimeMillis()))) {
                throw new Exception("Registration date cannot be in the future");
            }

            Customer customer = new Customer(0, name, phone, email, regDate);
            customerDAO.addCustomer(customer);
            JOptionPane.showMessageDialog(this, "Customer added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            dispose();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
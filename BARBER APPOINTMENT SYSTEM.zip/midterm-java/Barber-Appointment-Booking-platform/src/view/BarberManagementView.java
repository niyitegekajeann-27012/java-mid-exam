package view;

import dao.BarberDAO;
import model.Barber;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.util.List;

public class BarberManagementView extends JFrame {
    private JTextField nameField, specialtyField, phoneField;
    private JTable barberTable;
    private BarberDAO barberDAO;

    public BarberManagementView() {
        this.barberDAO = new BarberDAO();
        initializeUI();
    }

    private void initializeUI() {
        // Set frame properties
        setTitle("BarberBook - Manage Barbers");
        setSize(700, 600);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Set a light background color for the entire frame
        getContentPane().setBackground(new Color(240, 248, 255)); // Alice Blue

        // Header
        JLabel header = new JLabel("Manage Barbers", SwingConstants.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 24));
        header.setForeground(Color.WHITE); // White text
        header.setBackground(new Color(70, 130, 180)); // Steel Blue
        header.setOpaque(true); // Make background color visible
        header.setBorder(new EmptyBorder(10, 0, 10, 0)); // Add padding
        add(header, BorderLayout.NORTH);

        // Form panel for adding barbers (removed Availability Status)
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(3, 2, 10, 10)); // Reduced to 3 rows
        formPanel.setBackground(new Color(240, 248, 255)); // Alice Blue
        formPanel.setBorder(new EmptyBorder(10, 20, 10, 20)); // Add padding

        JLabel nameLabel = new JLabel("Barber Name:");
        nameLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        nameLabel.setForeground(new Color(60, 60, 60)); // Dark gray
        formPanel.add(nameLabel);
        nameField = new JTextField();
        nameField.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(nameField);

        JLabel specialtyLabel = new JLabel("Specialty:");
        specialtyLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        specialtyLabel.setForeground(new Color(60, 60, 60)); // Dark gray
        formPanel.add(specialtyLabel);
        specialtyField = new JTextField();
        specialtyField.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(specialtyField);

        JLabel phoneLabel = new JLabel("Phone:");
        phoneLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        phoneLabel.setForeground(new Color(60, 60, 60)); // Dark gray
        formPanel.add(phoneLabel);
        phoneField = new JTextField();
        phoneField.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(phoneField);

        add(formPanel, BorderLayout.NORTH);

        // Table for barbers
        String[] columns = {"ID", "Name", "Specialty", "Phone", "Availability"};
        List<Barber> barbers;
        try {
            barbers = barberDAO.getAllBarbers();
            if (barbers == null) {
                barbers = new java.util.ArrayList<>();
            }
        } catch (Exception e) {
            barbers = new java.util.ArrayList<>();
            JOptionPane.showMessageDialog(this, "Error loading barbers: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        Object[][] data = new Object[barbers.size()][5];
        for (int i = 0; i < barbers.size(); i++) {
            Barber b = barbers.get(i);
            data[i][0] = b.getBarberId();
            data[i][1] = b.getName();
            data[i][2] = b.getSpecialty();
            data[i][3] = b.getPhone();
            data[i][4] = b.getAvailabilityStatus();
        }

        barberTable = new JTable(data, columns);
        barberTable.setRowHeight(25); // Increase row height for better readability
        barberTable.setFont(new Font("Arial", Font.PLAIN, 14));
        barberTable.setBackground(Color.WHITE); // White background for table
        barberTable.setForeground(Color.BLACK); // Black text
        barberTable.setGridColor(new Color(200, 200, 200)); // Light gray grid lines
        barberTable.setSelectionBackground(new Color(173, 216, 230)); // Light Blue selection
        barberTable.setSelectionForeground(Color.BLACK);

        JTableHeader tableHeader = barberTable.getTableHeader();
        tableHeader.setBackground(new Color(100, 149, 237)); // Cornflower Blue
        tableHeader.setForeground(Color.WHITE); // White text
        tableHeader.setFont(new Font("Arial", Font.BOLD, 14));

        JScrollPane scrollPane = new JScrollPane(barberTable);
        scrollPane.setBorder(new EmptyBorder(10, 10, 10, 10)); // Add padding around the table
        add(scrollPane, BorderLayout.CENTER);

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        buttonPanel.setBackground(new Color(245, 245, 220)); // Beige background
        buttonPanel.setBorder(new EmptyBorder(10, 0, 10, 0)); // Add padding

        JButton addButton = new JButton("Add Barber");
        addButton.setFont(new Font("Arial", Font.BOLD, 14));
        addButton.setForeground(Color.WHITE);
        addButton.setBackground(new Color(60, 179, 113)); // Medium Sea Green
        addButton.setFocusPainted(false); // Remove focus border
        addButton.setBorder(new EmptyBorder(8, 15, 8, 15)); // Add padding inside button
        addButton.addActionListener(e -> addBarber());

        JButton updateStatusButton = new JButton("Update Status");
        updateStatusButton.setFont(new Font("Arial", Font.BOLD, 14));
        updateStatusButton.setForeground(Color.WHITE);
        updateStatusButton.setBackground(new Color(106, 90, 205)); // Slate Blue
        updateStatusButton.setFocusPainted(false); // Remove focus border
        updateStatusButton.setBorder(new EmptyBorder(8, 15, 8, 15)); // Add padding inside button
        updateStatusButton.addActionListener(e -> updateBarberStatus());

        JButton deleteButton = new JButton("Delete Barber");
        deleteButton.setFont(new Font("Arial", Font.BOLD, 14));
        deleteButton.setForeground(Color.WHITE);
        deleteButton.setBackground(new Color(255, 69, 0)); // OrangeRed
        deleteButton.setFocusPainted(false); // Remove focus border
        deleteButton.setBorder(new EmptyBorder(8, 15, 8, 15)); // Add padding inside button
        deleteButton.addActionListener(e -> deleteBarber());

        JButton backButton = new JButton("Back to Welcome");
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.setForeground(Color.WHITE);
        backButton.setBackground(new Color(147, 112, 219)); // Medium Purple
        backButton.setFocusPainted(false); // Remove focus border
        backButton.setBorder(new EmptyBorder(8, 15, 8, 15)); // Add padding inside button
        backButton.addActionListener(e -> {
            new WelcomeView().setVisible(true);
            dispose();
        });

        buttonPanel.add(addButton);
        buttonPanel.add(updateStatusButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(backButton);
        add(buttonPanel, BorderLayout.SOUTH);

        setLocationRelativeTo(null);
    }

    private void addBarber() {
        try {
            String name = nameField.getText();
            String specialty = specialtyField.getText();
            String phone = phoneField.getText();

            // Validate Name Required and Char Range
            if (name == null || name.trim().isEmpty()) {
                throw new Exception("Name is required");
            }
            if (name.length() < 2 || name.length() > 100) {
                throw new Exception("Name must be 2-100 characters");
            }

            // Validate Specialty Char Range
            if (specialty.length() < 5 || specialty.length() > 50) {
                throw new Exception("Specialty must be 5-50 characters");
            }

            if (phone == null || phone.trim().isEmpty()) {
                throw new Exception("Phone is required");
            }

            Barber barber = new Barber(0, name, specialty, phone, "Available"); // Default status
            barberDAO.addBarber(barber);
            JOptionPane.showMessageDialog(this, "Barber added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            // Refresh the view
            dispose();
            new BarberManagementView().setVisible(true);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateBarberStatus() {
        int selectedRow = barberTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a barber to update their status.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int barberId = (int) barberTable.getValueAt(selectedRow, 0); // Get barberId from the selected row
        String currentStatus = (String) barberTable.getValueAt(selectedRow, 4); // Get current status

        // Show a dialog to select the new status
        String[] statuses = {"Available", "Busy"};
        JComboBox<String> statusCombo = new JComboBox<>(statuses);
        statusCombo.setSelectedItem(currentStatus); // Set current status as default selection
        int option = JOptionPane.showConfirmDialog(this, statusCombo, "Update Barber Status", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String newStatus = statusCombo.getSelectedItem().toString();
            try {
                int rowsAffected = barberDAO.updateBarberStatus(barberId, newStatus);
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Barber status updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    // Refresh the view
                    dispose();
                    new BarberManagementView().setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to update barber status.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error updating barber status: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void deleteBarber() {
        int selectedRow = barberTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a barber to delete.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int barberId = (int) barberTable.getValueAt(selectedRow, 0); // Get barberId from the selected row
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this barber?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                int rowsAffected = barberDAO.deleteBarber(barberId);
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Barber deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    // Refresh the view
                    dispose();
                    new BarberManagementView().setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to delete barber.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error deleting barber: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
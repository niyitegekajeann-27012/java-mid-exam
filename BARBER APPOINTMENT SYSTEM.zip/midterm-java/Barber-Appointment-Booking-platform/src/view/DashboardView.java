package view;

import dao.AppointmentDAO;
import model.Appointment;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.util.List;

public class DashboardView extends JFrame {
    private JTable appointmentTable;
    private AppointmentDAO appointmentDAO;

    public DashboardView() {
        this.appointmentDAO = new AppointmentDAO();
        initializeUI();
    }

    private void initializeUI() {
        // Set frame properties
        setTitle("BarberBook - All Appointments");
        setSize(700, 500);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE); // Changed to DISPOSE_ON_CLOSE to close only this window
        setLayout(new BorderLayout());

        // Set a light background color for the entire frame
        getContentPane().setBackground(new Color(240, 248, 255)); // Alice Blue

        // Header
        JLabel header = new JLabel("All Appointments", SwingConstants.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 24));
        header.setForeground(Color.WHITE); // White text
        header.setBackground(new Color(70, 130, 180)); // Steel Blue
        header.setOpaque(true); // Make background color visible
        header.setBorder(new EmptyBorder(10, 0, 10, 0)); // Add padding
        add(header, BorderLayout.NORTH);

        // Table for appointments
        String[] columns = {"ID", "Customer ID", "Barber ID", "Date", "Status"};
        List<Appointment> appointments;
        try {
            appointments = appointmentDAO.getAllAppointments();
            if (appointments == null) {
                appointments = new java.util.ArrayList<>(); // Handle null return
            }
        } catch (Exception e) {
            appointments = new java.util.ArrayList<>();
            JOptionPane.showMessageDialog(this, "Error loading appointments: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        Object[][] data = new Object[appointments.size()][5];
        for (int i = 0; i < appointments.size(); i++) {
            Appointment a = appointments.get(i);
            data[i][0] = a.getAppointmentId();
            data[i][1] = a.getCustomerId();
            data[i][2] = a.getBarberId();
            data[i][3] = a.getAppointmentDate();
            data[i][4] = a.getStatus();
        }

        // Create and style the JTable
        appointmentTable = new JTable(data, columns);
        appointmentTable.setRowHeight(25); // Increase row height for better readability
        appointmentTable.setFont(new Font("Arial", Font.PLAIN, 14));
        appointmentTable.setBackground(Color.WHITE); // White background for table
        appointmentTable.setForeground(Color.BLACK); // Black text
        appointmentTable.setGridColor(new Color(200, 200, 200)); // Light gray grid lines
        appointmentTable.setSelectionBackground(new Color(173, 216, 230)); // Light Blue selection
        appointmentTable.setSelectionForeground(Color.BLACK);

        // Style the table header
        JTableHeader tableHeader = appointmentTable.getTableHeader();
        tableHeader.setBackground(new Color(100, 149, 237)); // Cornflower Blue
        tableHeader.setForeground(Color.WHITE); // White text
        tableHeader.setFont(new Font("Arial", Font.BOLD, 14));

        JScrollPane scrollPane = new JScrollPane(appointmentTable);
        scrollPane.setBorder(new EmptyBorder(10, 10, 10, 10)); // Add padding around the table
        add(scrollPane, BorderLayout.CENTER);

        
    }
}
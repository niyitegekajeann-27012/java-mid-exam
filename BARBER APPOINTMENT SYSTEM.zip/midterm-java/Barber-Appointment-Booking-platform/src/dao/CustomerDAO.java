
package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Customer;
public class CustomerDAO {
    private static String db_url = "jdbc:mysql://localhost:3306/barber_appointment_booking_system_db";
    private static String db_username = "root";
    private static String db_password = "DivDak19";
    
    public int addCustomer (Customer custObj){
        try(Connection con = DriverManager.getConnection(db_url, db_username, db_password)){
            String sql = "INSERT INTO Customer (name, phone, email, registrationDate) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setString(1, custObj.getName());
            pstmt.setString(2, custObj.getPhone());
            pstmt.setString(3, custObj.getEmail());
            pstmt.setDate(4, custObj.getRegistrationDate());
            int rowAffected = pstmt.executeUpdate();
            return rowAffected;   
        }catch(Exception ex){
            ex.printStackTrace();
            
        }
            return 0;
    }
    
      public List<Customer> getAllCustomers(){
        try(Connection con = DriverManager.getConnection(db_url, db_username, db_password)){
            String sql = "SELECT * FROM Customer";
            PreparedStatement pstmt = con.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            List<Customer> customerList = new ArrayList<>();
            while(rs.next()){
                Customer custObj = new Customer();
                custObj.setCustomerId(rs.getInt("customerId"));
                custObj.setName(rs.getString("name"));
                custObj.setPhone(rs.getString("phone"));
                custObj.setEmail(rs.getString("email"));
                custObj.setRegistrationDate(rs.getDate("registrationDate"));
                customerList.add(custObj);            
            }   
            return customerList;
        }catch(Exception ex){
            ex.printStackTrace();
            
        }
            return null;
    }  
       public int updateCustomer (Customer custObj){
        try(Connection con = DriverManager.getConnection(db_url, db_username, db_password)){
            String sql = "UPDATE Customer SET name = ?, phone = ?, email = ?, registrationDate = ? WHERE customerId = ?";
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setString(1, custObj.getName());
            pstmt.setString(2, custObj.getPhone());
            pstmt.setString(3, custObj.getEmail());
            pstmt.setDate(4, custObj.getRegistrationDate());
            int rowAffected = pstmt.executeUpdate();
            return rowAffected;   
        }catch(Exception ex){
            ex.printStackTrace();
            
        }
            return 0;
    }
      public Customer getCustomerById (int customerId){
        try(Connection con = DriverManager.getConnection(db_url, db_username, db_password)){
            String sql = "SELECT * FROM Customer WHERE customerId = ?";
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, customerId);
            ResultSet rs = pstmt.executeQuery();
            Customer theCustomer = new Customer();
            if(rs.next()){
                theCustomer.setCustomerId(rs.getInt("customerId"));
                theCustomer.setEmail(rs.getString("email"));
                theCustomer.setName(rs.getString("name"));
                theCustomer.setPhone(rs.getString("phone"));
                theCustomer.setRegistrationDate(rs.getDate("registrationDate"));
                
            }
            return theCustomer;
        }catch(Exception ex){
            ex.printStackTrace();
            
        }
            return null;
    } 
      public int deleteCustomer(Customer custObj) {
        try (Connection con = DriverManager.getConnection(db_url, db_username, db_password)) {
            String sql = "DELETE FROM customer WHERE customerId = ?;";
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, custObj.getCustomerId());
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
            return 0;

    }
       
    
}

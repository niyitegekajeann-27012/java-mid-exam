/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Appointment;

public class AppointmentDAO {
    private static String db_url = "jdbc:mysql://localhost:3306/barber_appointment_booking_system_db";
    private static String db_username = "root";
    private static String db_password = "DivDak19";
    
    public int addAppointment (Appointment appointment){
        try(Connection con = DriverManager.getConnection(db_url, db_username, db_password)){
            String sql = "INSERT INTO appointment (customerId, barberId, appointmentDate, status) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, appointment.getCustomerId());
            pstmt.setInt(2, appointment.getBarberId());
            pstmt.setTimestamp(3, appointment.getAppointmentDate());
            pstmt.setString(4, appointment.getStatus());
            int rowAffected = pstmt.executeUpdate();
            return rowAffected;   
        }catch(Exception ex){
            ex.printStackTrace();
            
        }
            return 0;
    }
    
      public List<Appointment> getAllAppointments() {
    try (Connection con = DriverManager.getConnection(db_url, db_username, db_password)) {
        String sql = "SELECT * FROM Appointment";
        PreparedStatement pstmt = con.prepareStatement(sql);
        ResultSet rs = pstmt.executeQuery();
        List<Appointment> appointmentList = new ArrayList<>();
        while (rs.next()) {
            Appointment apptObj = new Appointment();
            apptObj.setAppointmentId(rs.getInt("appointmentId"));
            apptObj.setCustomerId(rs.getInt("customerId"));
            apptObj.setBarberId(rs.getInt("barberId"));
            apptObj.setAppointmentDate(rs.getTimestamp("appointmentDate"));
            apptObj.setStatus(rs.getString("status"));
            appointmentList.add(apptObj);
        }
        return appointmentList;
    } catch (Exception ex) {
        ex.printStackTrace();
    }
    return null;
}  
       public int updateAppointment (Appointment appointment){
        try(Connection con = DriverManager.getConnection(db_url, db_username, db_password)){
            String sql = "UPDATE appointment SET customerId = ?, barberId = ?, appointmentDate = ?, status = ? WHERE appointmentId = ?";
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, appointment.getCustomerId());
            pstmt.setInt(2, appointment.getBarberId());
            pstmt.setTimestamp(3, appointment.getAppointmentDate());
            pstmt.setString(4, appointment.getStatus());
            pstmt.setInt(5, appointment.getAppointmentId());
            int rowAffected = pstmt.executeUpdate();
            return rowAffected;   
        }catch(Exception ex){
            ex.printStackTrace();
            
        }
            return 0;
    }
      public Appointment getAppointmentById (int appointmentId){
        try(Connection con = DriverManager.getConnection(db_url, db_username, db_password)){
            String sql = "SELECT * FROM appointment WHERE appointmentId = ?";
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, appointmentId);
            ResultSet rs = pstmt.executeQuery();
            Appointment theAppointment = new Appointment();
            if(rs.next()){
                theAppointment.setAppointmentId(rs.getInt("appointmentId"));
                theAppointment.setCustomerId(rs.getInt("customerId"));
                theAppointment.setBarberId(rs.getInt("barberId"));
                theAppointment.setAppointmentDate(rs.getTimestamp("appointmentDate"));
                theAppointment.setStatus(rs.getString("status"));          
            }
            return theAppointment;
        }catch(Exception ex){
            ex.printStackTrace();
            
        }
            return null;
    } 
      public int deleteAppointment(int appointmentId) {
        try (Connection con = DriverManager.getConnection(db_url, db_username, db_password)) {
            String sql = "DELETE FROM appointment WHERE appointmentId = ?;";
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, appointmentId);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
            return 0;

    }
    
}

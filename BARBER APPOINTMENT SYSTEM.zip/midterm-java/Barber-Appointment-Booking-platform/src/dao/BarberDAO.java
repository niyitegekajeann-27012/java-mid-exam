/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Barber;
public class BarberDAO {
    private static String db_url = "jdbc:mysql://localhost:3306/barber_appointment_booking_system_db";
    private static String db_username = "root";
    private static String db_password = "DivDak19";
    
    public int addBarber (Barber barber){
        try(Connection con = DriverManager.getConnection(db_url, db_username, db_password)){
            String sql = "INSERT INTO Barber (name, specialty, phone, availabilityStatus) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setString(1, barber.getName());
            pstmt.setString(2, barber.getSpecialty());
            pstmt.setString(3, barber.getPhone());
            pstmt.setString(4, barber.getAvailabilityStatus());
            int rowAffected = pstmt.executeUpdate();
            return rowAffected;   
        }catch(Exception ex){
            ex.printStackTrace();
            
        }
            return 0;
    }
    
      public List<Barber> getAllBarbers(){
        try(Connection con = DriverManager.getConnection(db_url, db_username, db_password)){
            String sql = "SELECT * FROM Barber";
            PreparedStatement pstmt = con.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            List<Barber> barberList = new ArrayList<>();
            while(rs.next()){
                Barber barber = new Barber();
                barber.setBarberId(rs.getInt("barberId"));
                barber.setName(rs.getString("name"));
                barber.setSpecialty(rs.getString("specialty"));
                barber.setPhone(rs.getString("phone"));
                barber.setAvailabilityStatus(rs.getString("availabilityStatus"));
                barberList.add(barber);            
            }   
            return barberList;
        }catch(Exception ex){
            ex.printStackTrace();
            
        }
            return null;
    }  
       public int updateBarber (Barber barber){
        try(Connection con = DriverManager.getConnection(db_url, db_username, db_password)){
            String sql = "UPDATE Barber SET name = ?, specialty = ?, phone = ?, availabilityStatus = ? WHERE barberId = ?";
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setString(1, barber.getName());
            pstmt.setString(2, barber.getSpecialty());
            pstmt.setString(3, barber.getPhone());
            pstmt.setString(4, barber.getAvailabilityStatus());
            int rowAffected = pstmt.executeUpdate();
            return rowAffected;   
        }catch(Exception ex){
            ex.printStackTrace();
            
        }
            return 0;
    }
      public Barber getBarberById (int barberId){
        try(Connection con = DriverManager.getConnection(db_url, db_username, db_password)){
            String sql = "SELECT * FROM Barber WHERE barberId = ?";
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, barberId);
            ResultSet rs = pstmt.executeQuery();
            Barber theBarber = new Barber();
            if(rs.next()){
                theBarber.setBarberId(rs.getInt("barberId"));
                theBarber.setName(rs.getString("name"));
                theBarber.setSpecialty(rs.getString("specialty"));
                theBarber.setPhone(rs.getString("phone"));
                theBarber.setAvailabilityStatus(rs.getString("availabilityStatus"));          
            }
            return theBarber;
        }catch(Exception ex){
            ex.printStackTrace();
            
        }
            return null;
    } 
      public int deleteBarber(int barberId) {
        try (Connection con = DriverManager.getConnection(db_url, db_username, db_password)) {
            String sql = "DELETE FROM barber WHERE barberId = ?;";
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, barberId);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
            return 0;

    }
      public int updateBarberStatus(int barberId, String newStatus) {
        try (Connection con = DriverManager.getConnection(db_url, db_username, db_password)) {
            String sql = "UPDATE Barber SET availabilityStatus = ? WHERE barberId = ?";
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setString(1, newStatus);
            pstmt.setInt(2, barberId);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return 0;
    }
    
}
